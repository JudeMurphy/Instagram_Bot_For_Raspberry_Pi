"""
    instabot example

    Workflow:
        Follow user's followers by username.
"""

import argparse
import os
import sys

sys.path.append(os.path.join(sys.path[0], '../'))
from instabot import Bot

bot = Bot()
bot.login(username="brewery.helper", password="Macbook12$",
          proxy="")

bot.follow_followers("brewery.helper")
