"""
    instabot example

    Workflow:
        Follow users who liked the last media of input users.
"""

import argparse
import os
import sys

from tqdm import tqdm

sys.path.append(os.path.join(sys.path[0], '../'))
from instabot import Bot

bot = Bot()
bot.login(username="USERNAME", password="PASSWORD", proxy="")

medias = bot.get_user_medias("USERNAME", filtration=False)
likers = bot.get_media_likers(medias[0])
for liker in tqdm(likers):
     bot.follow(liker)