"""
    instabot example

    Workflow:
        Like last images with hashtag.
"""

import argparse
import os
import sys

sys.path.append(os.path.join(sys.path[0], '../'))
from instabot import Bot

parser = argparse.ArgumentParser(add_help=True)
parser.add_argument('hashtags', type=str, nargs='+', help='hashtags')
args = parser.parse_args()

bot = Bot()
bot.login(username="USERNAME", password="PASSWORD", proxy="")

for hashtag in args.hashtags:
    bot.like_hashtag(hashtag)
