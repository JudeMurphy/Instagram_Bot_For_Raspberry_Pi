from .bot import Bot

assert Bot  # silence pyflakes
